﻿define("epi-cms/contentediting/WorkflowTaskNotification", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/topic",
    "dojo/when",
// dojox
    "dojox/html/entities",
// epi
    "epi/datetime",
    "epi/dependency",
    "epi/string",
    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/command/WorkflowTask",
// resources
    "epi/i18n!epi/ui/nls/personalization.task"
],

function (
// dojo
    array,
    declare,
    lang,
    Stateful,
    topic,
    when,
// dojox
    htmlEntities,
// epi
    epiDateTime,
    dependency,
    epiString,
    ApplicationSettings,
    WorkflowTask,
// resources
    resources
) {

    return declare([Stateful], {
        // summary:
        //      Workflow task notification
        // description:
        //      Show notification for workflow task on a related page
        // tags:
        //      internal

        model: null,

        notification: null,

        _store: null,

        taskStatus: [
            "statusnotstarted", // The task has not started yet
            "statusinprogress", // The task is in progress
            "statuscompleted", // The task has been completed
            "statusrejected" // The task has been rejected.
        ],

        postscript: function () {
            this.inherited(arguments);
            this._store = this._store || dependency.resolve("epi.storeregistry").get("epi.cms.workflowtask");
        },

        _modelSetter: function (/*Object*/value) {
            // summary:
            //      Updates the model and performs notification checks
            // tags:
            //      private

            this.model = value;

            if(!ApplicationSettings.isWorkflowsEnabled) {
                return;
            }

            if (value && value.contentLink) {
                when(this._store.query({ id: value.contentLink }),
                    lang.hitch(this, this._updateNotifications),
                    lang.hitch(this, this._clearNotifications)
                );
            } else {
                this._clearNotifications();
            }
        },

        _updateNotifications: function (/*Array*/tasks) {
            // summary:
            //      Set notification(s) when executed success from store call
            // tags:
            //      private

            var notifications = array.map(tasks, function (task) {
                return {
                    content: epiString.toHTML(this._renderMessage(task)),
                    commands: [new WorkflowTask({ model: { contentData: this.model, task: task } })]
                };
            }, this);

            // Update workflow task notification(s)
            this.set("notification", notifications);

            // Publish event to update MyTasks component if tasks is empty
            if (!tasks || tasks.length === 0) {
                topic.publish("/epi/cms/action/refreshmytasks");
            }
        },

        _clearNotifications: function () {
            // summary:
            //      Empty notification if store call failed
            // tags:
            //      protected

            this.set("notification", []);
        },

        _renderMessage: function (/*Object*/task) {
            // summary:
            //      Render notification content description text that based on the given task information
            //      Message formats: "{task.status}, due date {task.dueDate}, {task.subject}"
            // tags:
            //      private

            // Get the given task subject text
            var message = task.subject && task.subject.length > 0 ? htmlEntities.encode(task.subject) : "-";

            // Get the given task due date text
            message += task.dueDate ? lang.replace(", {0} {1}", [resources.duedate.toLowerCase(), epiDateTime.toUserFriendlyString(task.dueDate)]) : "";

            // Get the given task status text
            message += ", " + resources[this.taskStatus[task.status]];

            return message;
        }
    });
});